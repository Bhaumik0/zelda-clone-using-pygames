import pygame

class Game():
    def __init__():
        pygame.init()
        self.running, self.playing=Ture, False
        self.UP_KEY,self.DOWN_KEY,self.START_KEY,self.BACK_KEY = False, False, False, False
        self.DISPLAY_W, self.DISPLAY_H= 1280, 720
        self.display = pygame.Surface((self.DISPLAY_W,self.DISPLAY_H))
        self.window= pygame.display.set_mode(((self.DISPLAY_W,self.DISPLAY_H)))
        self.font_name='8-BIT WONDER.TTF'
        #self.font_name=pygame.font.get_default_font()
        self.BLACK, self.WHITE=(0,0,0), (255,255,255)
    
    def game_loop(self):
        while self.playing:
           self.cleck_events()
           if self.START_KEY:
               self.playing=False
           self.display.fill(self.BLACK)

    def check_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running,self.playing= False, False
            if event.type== pygame.KEYDOWN:
                if event.key == pygame.k_RETURN:
                    self.START_KEY= True
                if event.key == pygame.k_BACKSPACE:
                    self.BACK_KEY= True
                if event.key == pygame.k_DOWN:
                    self.DOWN_KEY= True
                if event.key == pygame.k_UP:
                    self.UP_KEY= True
 
